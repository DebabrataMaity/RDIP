function getHistory(){
	return document.getElementById("history-value").innerText;
}
function printHistory(num){
	document.getElementById("history-value").innerText=num;
	return document.getElementById("history-value").innerText=num;
}
function getOutput(){
	return document.getElementById("output-value").innerText;
}
function printOutput(num){
	if(num==""){
		document.getElementById("output-value").innerText=num;
	}
	else{
		document.getElementById("output-value").innerText=getFormattedNumber(num);
	}	
}
function getFormattedNumber(num){
	if(num=="-"){
		return "";
	}
	var n = Number(num);
	var value = n.toLocaleString("en");
	return value;
}
function reverseNumberFormat(num){
	return Number(num.replace(/,/g,''));
}
var operator = document.getElementsByClassName("operator");
for(var i =0;i<operator.length;i++){
	operator[i].addEventListener('click',function(){
		if(this.id=="clear"){
			printHistory("");
			printOutput("");
		}
		else if(this.id=="backspace"){
			var output=reverseNumberFormat(getOutput()).toString();
			if(output){//if output has a value
				output= output.substr(0,output.length-1);
				printOutput(output);
			}
		}
		else{
			var output=getOutput();
			var history=getHistory();
			if(output==""&&history!=""){
				if(isNaN(history[history.length-1])){
					history= history.substr(0,history.length-1);
				}
			}
			if(output!="" || history!=""){
				output= output==""?output:reverseNumberFormat(output);
				history=history+output;
				if(this.id=="="){
					var result=eval(history);
					printOutput(result);
					printHistory("");
				}
				else{
					history=history+this.id;
					printHistory(history);
					printOutput("");
				}
			}
		}
		
	});
}
var number = document.getElementsByClassName("number");
for(var i =0;i<number.length;i++){
	number[i].addEventListener('click',function(){
		var output=reverseNumberFormat(getOutput());
		if(output!=NaN){ //if output is a number
			output=output+this.id;
			printOutput(output);
		}
	});
}
function validation(){
var user=document.getElementById('user').value;
var number=document.getElementById('number').value;
var email=document.getElementById('email').value;

if(user==""){
document.getElementById('name').innerHTML="Please fill the name field";
return false;
}
if(user.length<3 || user.length>20)
{
document.getElementById('name').innerHTML="user length must be between 2 to 20";
return false;
}
if(!isNaN(user) || !isNaN(user.charAt(0)))
{
document.getElementById('name').innerHTML="Only characters are allowed";
return false;
}
if(number==""){
document.getElementById('pnumber').innerHTML="Please fill the phone number field";
return false;
}
if(isNaN(number)){
document.getElementById('pnumber').innerHTML="user must write digits only not characters";
return false;
}
if(number.length!=10){
document.getElementById('pnumber').innerHTML="Mobile number must be 10 digit";
return false;
}
if(email==""){
document.getElementById('mail').innerHTML="Please fill the email field";
return false;
}
if(email.indexOf('@')<=0){
document.getElementById('mail').innerHTML="@ invlaid position";
return false;
}
if(email.CharAt(email.length-4)!='.' && email.CharAt(email.length-3)!='.')
{
document.getElementById('mail').innerHTML=". invlaid position";
return false;
}
}

function checkPalindrome() {
var revStr = "";
var str = document.getElementById("str").value;
var i = str.length;
for(var j=i; j>=0; j--) {
revStr = revStr+str.charAt(j);
}
if(str == revStr) {
alert(str+" -is Palindrome");
} else {
alert(str+" -is not a Palindrome");
}
}


var button = document.getElementById('button-test');
button.addEventListener('click', checkAnagram);
button.addEventListener('click', game);
var resultDiv = document.getElementById('result');

function checkAnagram() {
  var str1 = document.getElementById('string1').value;
  var str2 = document.getElementById('string2').value;
  if(str1 !== null && str2 !== null) {
    if(str1.length !== str2.length) {
      resultDiv.innerHTML = "Strings are not anagrams.";
      return false;
    }
    var hashTable = {};
    for(var i = 0; i < str1.length; i++) {
      if(hashTable.hasOwnProperty(str1[i])) {
        hashTable[str1[i]] = hashTable[str1[i]] + 1;
    } else {
     hashTable[str1[i]] = 1;
    }
  }

  for(var i = 0; i < str2.length; i++) {
    if(hashTable.hasOwnProperty(str2[i])) {
      hashTable[str2[i]] = hashTable[str2[i]] - 1;
    } else {
      resultDiv.innerHTML = "Strings are not anagrams.";
      return false;
    }
  }

  for(var i in hashTable) {
    if(hashTable[i] !== 0) {
      resultDiv.innerHTML = "Strings are not anagrams.";
      return false;
    } else {
       resultDiv.innerHTML = "Strings are anagrams!";
    }
  }
}
}

function game(){
  var str1 = document.getElementById('string1').value%3;
  var str2 = document.getElementById('string2').value%3;
  //human->0
  //cockroach->1
  //Nuclear bomb->2
  if(str1==0 && str2==1 || str1==1 && str2==0)
  {
    resultDiv.innerHTML = "Human Survives";
      return false;
  }
  if(str1==0 && str2==2 || str1==2 && str2==0)
  {
    resultDiv.innerHTML = "Human Dies";
      return false;
  }
  if(str1==1 && str2==2 || str1==2 && str2==1)
  {
    resultDiv.innerHTML = "Cockroach Survives";
      return false;
  }
  else
  {
  resultDiv.innerHTML = "Game ties";
      return false;
  }
}

button.addEventListener('click', convertCurrency);

function convertCurrency()
{
var from=document.getElementById("from").value;
var to=document.getElementById("to").value;
var xmlhttp=new XMLHttpRequest();
var url="https://free.currconv.com/api/v7/convert?q="+ from + "_" + to + "&compact=ultra&apiKey=ecd96f38ab9cbbe978b7";
//var url="http://api.fixer.io/latest?symbols=" + from + "," + to;
xmlhttp.open("GET",url,true);
xmlhttp.send();
xmlhttp.onreadystatechange=function(){
if(xmlhttp.readyState==4 && xmlhttp.status==200)
{
var result=xmlhttp.responseText;
var one=result.slice(11,16);
var two=parseFloat(one);
//var jsResult=JSON.parse(result);

//var oneUnit=jsResult.USD_INR;

var amt=document.getElementById("fromAmount").value;
alert(amt*two);
resultDiv.innerHTML = "converted value:"+ amt*two;
      return false;
}
}
}